import javax.swing.*; 
import javax.swing.filechooser.FileNameExtensionFilter;  
import java.awt.event.*; 
import java.awt.Graphics;
import java.awt.Dimension;
import java.awt.*;
import java.io.*; 
import java.util.List;
import java.util.ArrayList; 
import javax.swing.JLabel;
import java.net.URL;
 
public class FileChooserGPX extends JFrame implements ActionListener{    
		JMenuBar mb;    
		JMenu file;    
		JMenuItem open;    
		JTextArea ta; 
		FileChooserGPX(){    
			open=new JMenuItem("Open File");    
			open.addActionListener(this);            
			file=new JMenu("File");    
			file.add(open);             
			mb=new JMenuBar();    
			mb.setBounds(0,0,800,20);    
			mb.add(file);              
			ta=new JTextArea(50,50); 
			
			ta.setEditable(false);
			ta.setBounds(0,20,800,800);
		
			add(mb);    
			add(ta);              
		}    
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == open) {
				JFileChooser fc = new JFileChooser();
				fc.setFileFilter(new FileNameExtensionFilter("GPX Files", "gpx"));
				int i = fc.showOpenDialog(this);
				if (i == JFileChooser.APPROVE_OPTION) {
					File f = fc.getSelectedFile();
					String filepath = f.getPath();
					try {
						BufferedReader br = new BufferedReader(new FileReader(filepath));
						String line;
						String[] trkptLines = new String[100000];
						String[] eleLines = new String[100000];
						int line1_len = 0;
						int line2_len = 0;

						while ((line = br.readLine()) != null) {
							
							if (line.contains("<trkpt")) {
								
								trkptLines[line1_len]=line;
								line1_len++;
							}
							if (line.contains("<ele")) {
								eleLines[line2_len] = line;
								line2_len++;
							}
							
						}
    
						// Converteste listele de linii intr-un array de string-uri
						// String[] trkptArray = trkptLines.toArray(new String[0]);
						// String[] eleArray = eleLines.toArray(new String::new);
						
						//Iau doar valorile latitudinilor, respectiv longitudinilor si convertesc in double
						//si le afisez
						double[] latitudine = new double[line1_len];
						double[] longitudine = new double[line1_len];
						double[] elevatia = new double[line2_len];
						
						//ta.append("Latitudinea, longitudinea si elevatia :\n");
						for(int j = 0;j < line1_len; j++)
						{
							String temp = trkptLines[j];
							String[] temp_output = temp.split(" ");
							for(int z = 0;z < temp_output.length;z++){
								if(temp_output[z].startsWith("lat")){
									String value = temp_output[z].substring(5, temp_output[z].length() - 1);
									latitudine[j] = Double.parseDouble(value);
								}
								if(temp_output[z].startsWith("lon")){
									String value = temp_output[z].substring(5, temp_output[z].length() - 2);
									longitudine[j] = Double.parseDouble(value);
								}
							}
						}
						for(int j = 2;j < line2_len;j++){
							
							String value = eleLines[j].substring(9,eleLines[j].length() - 6);
							elevatia[j] = Double.parseDouble(value);
							
						}
						// for(int j = 2;j < line1_len;j++){
							// ta.append("lat : " + latitudine[j] + " ");
							// ta.append("lon : " + longitudine[j] + " ");
							// ta.append("elevatie : " + elevatia[j] + " ");
							// ta.append("\n");
						// }
						
						double[] distances = new double[latitudine.length - 1];

						for (int a = 2; a < latitudine.length - 1; a++) {
							double lat1 = Math.toRadians(latitudine[a]);
							double lat2 = Math.toRadians(latitudine[a+1]);
							double lon1 = Math.toRadians(longitudine[a]);
							double lon2 = Math.toRadians(longitudine[a+1]);

							double d = 3963.0 * Math.acos(Math.sin(lat1)*Math.sin(lat2) + Math.cos(lat1)*Math.cos(lat2)*Math.cos(lon2-lon1));
							d *= 1.609344;
							
							distances[a] = d;

							//ta.append("distanta  " + a + " : " + distances[a] + " km");
							//ta.append("\n");
						}
						
						double max1 = elevatia[0];
						double min1 = elevatia[0];
						for (int b = 1; b < elevatia.length; b++) {
							if (elevatia[b] > max1) {
								max1 = elevatia[b];
							}
							if (elevatia[b] < min1) {
								min1 = elevatia[b];
							}
						}
						final double eleMax = max1;
						final double eleMi = min1;
						
						double max2 = distances[0];
						double min2 = distances[0];
						for (int b = 1; b < distances.length; b++) {
							if (distances[b] > max2) {
								max2 = distances[b];
							}
							if (distances[b] < min2) {
								min2 = distances[b];
							}
						}
						final double distMax = max2;
						final double distMin = min2;
						
						JPanel jp = new JPanel() {
							@Override
							protected void paintComponent(Graphics g) {
								super.paintComponent(g);
								Graphics2D g2d = (Graphics2D) g;
								g2d.setStroke(new BasicStroke(2));
								int fontSize = 12;
								g2d.setFont(new Font("TimesRoman", Font.PLAIN, fontSize + 2));


								// Setam culoarea pentru axele x si y
								g2d.setColor(Color.BLACK);

								// Desenam axa x
								g2d.drawLine(50, 800, 1500, 800);
								
								int k = 20;
								int l = 0;
								double m = distMax * 1000;
								
								g2d.setColor(Color.black);
								int	metres = (int) m;
								for(int i = 0;i < metres; i = i + (metres / k)){
									String S = Integer.toString(i);
									g2d.drawString(S, 50 + (1455 / k) * l -5 , 818);
									l++;
									if(l > k) break;
								}
								g2d.drawString("[m]", 1513, 806);

								// Desenam axa y
								g2d.drawLine(50, 10, 50, 800);
								
								int q = 20;
								int w = 0;
														
								g2d.setColor(Color.black);
								int	metres1 = (int) eleMax;
								for(int i = 0;i < metres1; i = i + (metres1 / q)){
									String S1 = Integer.toString(i);
									g2d.drawString(S1, 5, 795 - (795/ q) * w + 5);
									w++;
								}
								
								g2d.drawString("[m]", 60, 20);
								//puctulete pt elevatie cum am facut pt distanta
								
								// Setam culoarea pentru puncte si linii
								g2d.setColor(new Color(95,158,160));
								
								
								// Desenam punctele si legaturile dintre ele
																//calculez valoarea maxima si minima din fiecare vector (x si y de mai sus) xValues, yValues;
								//Daca valoarea maxima trece de 1500( lungimea maxima a ecranului meu)
								//Atunci trebuie sa scalez TOATE numerele
								//parcurg numerele si fiecare numar o sa devina ( xValues[i] = scaledNumber(xValues[i],1500,50,xMAX,xMIN) 
								//La fel si pentru y;
								//dupa scalare continui procesul de desenare de mai jos;
								//Parcurg xvalues( care o sa aiba aceeasi lungime cu yValues)
								//int x = xValues[i], y = yValues[i];
								//acuma tu lucrezi cu cei 2 vectori de mai sus nu cu vectorul distances.
									// Deseneaza punctul
									
									
									// Daca nu suntem la primul punct, traseaza o linie intre acesta si punctul anterior
									// if (i > 0) {
										// int xPrev = 50 + (int)((i - 1) * (1300.0 / distances.length)) - 3;
										// int yPrev = 825 - (int)(elevatia[i - 1] * (825.0 / max));
										// g2d.drawLine(xPrev, yPrev, x, y);
									// }
								int[] xValues = new int[distances.length];
								int[] yValues = new int[distances.length];
								for (int i = 0; i < distances.length; i++) {
									// Calculeaza pozitia punctului pe grafic
									int x = 50 + (int)(i * (1500.0 / distances.length)) - 3;
									xValues[i] = x;
									//System.out.println(xValues[i]);
									
									int y = 800 - (int)(elevatia[i] * (800.0 / eleMax));
									yValues[i] = y;
									//Pun cei 2 valori in 2 vectori, unul pt x si unul pt y de mai sus
								}
								int xMAX = xValues[0];
								int xMIN = xValues[0];
								for(int i = 1;i < xValues.length; i++){
									if(xValues[i] > xMAX){
										xMAX = xValues[i];
									}
									if(xValues[i] < xMIN){
										xMIN = xValues[i];
									}
								}
								int yMAX = yValues[0];
								int yMIN = yValues[0];
								for(int i = 1;i < xValues.length; i++){
									if(yValues[i] > yMAX){
										yMAX = yValues[i];
									}
									if(yValues[i] < yMIN){
										yMIN = yValues[i];
									}
								}
								if(xMAX > 1500){
									for(int i = 0;i < xValues.length; i++){
										xValues[i] = scaledNumber(xValues[i],1500,50,xMAX,xMIN);
										//System.out.println(xValues[i]);
									}
								}
								if(yMAX > 800){
									for(int i = 0;i < yValues.length; i++){
										yValues[i] = scaledNumber(yValues[i],800,50,yMAX,yMIN);
										//System.out.println(yValues[i]);
									}
								}

								// Setăm culoarea pentru umplerea sub grafic
								g2d.setColor(new Color(95,158,160)); // am pus culoarea cadet blue

								// Creăm un poligon care să reprezinte suprafața sub grafic
								int[] xPoints = new int[xValues.length + 2];
								int[] yPoints = new int[yValues.length + 2];
								xPoints[0] = 50;
								yPoints[0] = 800;
								//System.out.println(xPoints[0]);
								xPoints[xValues.length + 1] = 50 + (int)(1300.0);
								yPoints[yValues.length + 1] = 800;
								//System.out.println(xPoints[xValues.length + 1]);
								for (int i = 0; i < xValues.length; i++) {
									xPoints[i+1] = 50 + (int)(i * (1300.0 / xValues.length));
									//System.out.println(xPoints[i]);
								}
								for (int i = 0; i < yValues.length; i++) {
									yPoints[i+1] = 800 - (int)(elevatia[i] * (800.0 / eleMax));
									//System.out.println(yPoints[i]);
								}
								Polygon polygon = new Polygon(xPoints, yPoints, xPoints.length);

								// Umplem poligonul cu culoarea setată mai sus
								g2d.fillPolygon(polygon);
							}

							@Override
							public Dimension getPreferredSize() {
								return new Dimension(800, 600);
							}
							
						};
						jp.setBackground(new Color(176,224,230)); // set the background color of the jp panel
						
						// Creează un obiect JFrame
						JFrame frame = new JFrame("Track Analyser");
						frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
						frame.getContentPane().setBackground( Color.blue );
						frame.setResizable(false);
						
						// Adauga panoul care afiseaza graficul la frame
						frame.add(jp, BorderLayout.CENTER);

						frame.setLocation(0, 0);
						frame.setVisible(true);
						
						//frame.add(jp);
						
						
						br.close();
					}
					catch (Exception ex) {
							ex.printStackTrace();
					}
				}
			} 
		}	
		public int scaledNumber(int toScaleNumber, int Max, int Min, int scaleNumberMax, int scaleNumberMin){
			double scale = scaleNumberMax - scaleNumberMin;
			double output = Max - Min;
			double procent = (toScaleNumber - Min) / scale;
			double outputValue = (procent * output) + Min;
			return (int) outputValue;
		}		
		
		public static void main(String[] args) {    
			FileChooserGPX om=new FileChooserGPX();    
            om.setSize(500,500);    
            om.setLayout(null);    
            om.setVisible(true);    
            om.setDefaultCloseOperation(EXIT_ON_CLOSE);    
		}    
}  